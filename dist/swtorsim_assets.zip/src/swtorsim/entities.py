"""Combat actor entities (Entity, Player, Dummy), stat recalculation, and timer/effect scaling."""

import math
from typing import Any, Optional
from src.swtorsim.resources import create_resource_pool
from collections import defaultdict #performance choice
from src.swtorsim.combat_curves import (
    ACCURACY_RATING,
    ALACRITY_RATING,
    CRITICAL_CHANCE_TARGET,
    CRITICAL_DAMAGE_TARGET,
    CRITICAL_RATING,
    MASTERY,
    derived_stat,
)
from src.swtorsim.combat_math import calc_dr
from src.swtorsim.effects import ActiveEffect, EffectCollection, _effect_charge_mods, reconcile_charge_caps


class Entity:
    """Base class for combat entities managing active effects and stat recalculation triggers."""
    RECALCULATE_STATS = set()
    def __init__(self, name: str):
        self.name = name
        self.max_hp = 1_000_000
        self.hp = 1_000_000
        self.is_player = False
        self.immune_by_resolve = False
        self.in_combat = False
        self.is_in_cover = False
        self.is_in_portable_cover = False
        self.is_stealthed = False
        self.effects = EffectCollection()
        self.stats = {}
        self.active_channel = None
        self.is_channeling = False
        self.active_cast = None
        self.is_casting = False
        self._base_immunities = set()

    @property
    def immunities(self) -> set[str]:
        """Returns the set of active immunity tags from active effects and base immunities."""
        active_tags = set(self._base_immunities)
        for eff in self.effects.values():
            if not getattr(eff, "is_expired", False):
                active_tags.update(getattr(eff, "immunities", ()))
        return active_tags

    def has_immunity(self, tag: str) -> bool:
        """Returns True if the entity is currently immune to the given tag."""
        return tag in self.immunities

    def is_immune_to_effect(self, effect) -> bool:
        """Returns True if the entity is immune to any tag of the incoming effect."""
        tags = getattr(effect, "tags", ()) or ()
        active_immunities = self.immunities
        if not active_immunities or not tags:
            return False
        return any(t in active_immunities for t in tags)

    def interrupt(self, sim=None) -> bool:
        """Interrupts active cast or channel unless the entity has interrupt immunity."""
        if self.has_immunity("tag.abl.debuff.interrupt"):
            return False
        interrupted = False
        if self.is_channeling and self.active_channel is not None:
            self.active_channel.is_finished = True
            self.active_channel = None
            self.is_channeling = False
            interrupted = True
        if self.is_casting:
            self.active_cast = None
            self.is_casting = False
            interrupted = True
        return interrupted

    def _drop_replaced_effect(self, key, eff, sim) -> None:
        """Removes an effect superseded by an ``is_by_tag`` replacement without expiring it.

        The instance stays un-expired so the replacement can inherit its stacks/expiry, but its
        trigger subscriptions are removed (otherwise they keep firing for an effect that no longer
        exists), the removal is logged, and stats are recalculated if it carried modifiers.
        """
        if self.effects.get(key) is not eff:
            return
        self.effects.pop(key, None)
        owner_id = getattr(eff, "owner_id", None)
        if sim is not None and owner_id and hasattr(sim, "triggers"):
            sim.triggers.unsubscribe(owner_id)
        if sim is not None:
            display_name = getattr(eff, "name", None) or getattr(eff, "fqn", None) or key
            if getattr(sim, "tracker", None) is not None and hasattr(sim.tracker, "log_effect_removed"):
                sim.tracker.log_effect_removed(self.name, display_name, getattr(sim, "current_time", 0.0))
            if getattr(sim, "tracer", None) is not None:
                sim.tracer.record_buff_expired(getattr(sim, "current_time", 0.0), self.name, display_name)
        if getattr(eff, "modifiers", None) and hasattr(self, "recalculate_stats"):
            self.recalculate_stats()

    def apply_effect(self, sim, ability, effect, caster=None): #can be improved on the refresh
        """Applies or refreshes an extracted ActiveEffect, calculates expiration, and triggers stat updates if needed."""
        current_time = sim.current_time if sim is not None else 0.0
        raw_duration = float(getattr(effect, "duration", 0.0) or 0.0)
        if caster is not None and hasattr(caster, "calculate_effect_duration"):
            base_duration = caster.calculate_effect_duration(raw_duration, ability=ability, effect=effect)
        else:
            base_duration = raw_duration
        ignore_alacrity = bool(getattr(effect, "eff_ignore_alacrity", True))
        # Effects applied while the character loads (sim.loading) scale with the Alacrity stat only; anything applied
        # later (including passive ticks applied by a trigger) uses total Alacrity.
        scale_time = None
        if caster is not None:
            scale_time = caster.scale_time_modifier if getattr(sim, "loading", False) else caster.scale_time_total

        if base_duration > 0.0 and not ignore_alacrity and caster is not None:
            duration = scale_time(base_duration)
        else:
            duration = base_duration

        is_passive = bool(getattr(effect, "is_passive", False))
        expires_at = (current_time + duration) if (duration > 0.0 and not is_passive) else None

        effect_instance = ActiveEffect.from_effect(
            ability=ability,
            effect=effect,
            current_time=current_time,
            expires_at=expires_at,
            caster=caster or self,
            target=self,
            sim=sim,
        )
        parent_fqn = (
            getattr(getattr(ability, "blueprint", None), "fqn", None)
            or getattr(ability, "fqn", None)
            or getattr(ability, "name", "")
        )
        effect_number = getattr(effect, "number", None)
        raw_effect_name = getattr(effect, "name", None)

        if parent_fqn and effect_number is not None:
            canonical_id = f"{parent_fqn}:{effect_number}"
        elif getattr(effect_instance, "fqn", None) and getattr(effect_instance, "number", None) is not None:
            canonical_id = f"{effect_instance.fqn}:{effect_instance.number}"
        else:
            canonical_id = raw_effect_name or effect_instance.name or f"effect_{id(effect_instance)}"

        effect_key = canonical_id
        display_name = raw_effect_name or effect_instance.name or effect_key

        raw_tick = float(getattr(effect, "tick_interval", 0.0) or 0.0)
        if raw_tick > 0.0 and caster is not None and hasattr(caster, "calculate_effect_tick"):
            base_tick = caster.calculate_effect_tick(raw_tick, ability=ability, effect=effect)
        else:
            base_tick = raw_tick
        if base_tick > 0.0 and base_duration > 0.0:
            total_ticks = max(1, int(round(base_duration / base_tick)))
            scaled_tick = duration / total_ticks
        elif is_passive and getattr(ability, "type", None) == "passive" and base_tick > 0.0:
            # Effects of passive abilities (e.g. Terminal Velocity) have no duration, so they tick indefinitely.
            # Active abilities (channels) flag effects passive too, but their ticks are driven by the channel.
            # DotTick reads passive_tick_base to reschedule itself at this fixed interval and never expires the effect.
            total_ticks = 0
            scaled_tick = scale_time(base_tick) if (not ignore_alacrity and caster is not None) else base_tick
            effect_instance.passive_tick_base = base_tick
        else:
            total_ticks = 0
            scaled_tick = None

        effect_instance.caster_ref = caster
        effect_instance.duration = duration
        effect_instance.tick_interval = scaled_tick
        effect_instance.total_ticks = total_ticks
        effect_instance.ticks_remaining = total_ticks

        existing = self.effects.get(effect_key)
        stack_charge = getattr(effect, "stack_charge", None) or {}
        is_by_tag = bool(stack_charge.get("is_by_tag", False))
        nr_occurances = int(stack_charge.get("nr_occurances", 1) or 1)
        rel_tags_raw = stack_charge.get("relevant_tags")

        if is_by_tag and rel_tags_raw and existing is None:
            rel_tags = {rel_tags_raw} if isinstance(rel_tags_raw, str) else set(rel_tags_raw)
            for existing_k, existing_eff in list(self.effects.items()):
                if getattr(existing_eff, "is_expired", False):
                    continue
                is_dummy_debuff = (
                    getattr(existing_eff, "is_passive", False)
                    and getattr(existing_eff, "expires_at", None) is None
                )
                if not getattr(existing_eff, "is_by_tag", False) and not is_dummy_debuff:
                    continue
                eff_tags = getattr(existing_eff, "tags", frozenset())
                if rel_tags & set(eff_tags):
                    if nr_occurances == 1:
                        self._drop_replaced_effect(existing_k, existing_eff, sim)
                    if is_dummy_debuff or nr_occurances != 1:
                        existing = existing_eff
                    break

        if existing is not None and not getattr(existing, "is_expired", False):
            can_accumulate_stacks = (
                effect_instance.max_stacks > 1
                and effect_instance.initial_stacks < effect_instance.max_stacks
            )
            if can_accumulate_stacks:
                effect_instance.stacks = min(
                    effect_instance.max_stacks,
                    getattr(existing, "stacks", 1) + 1,
                )
            else:
                effect_instance.stacks = max(
                    getattr(existing, "stacks", 1),
                    getattr(effect_instance, "initial_stacks", 1),
                )
            if existing.expires_at is None:
                effect_instance.expires_at = None
                effect_instance.is_passive = getattr(existing, "is_passive", False)
            elif expires_at is not None:
                effect_instance.expires_at = max(existing.expires_at, expires_at)
            # A refresh does not re-run on_apply, so what that first application granted stays with the effect.
            effect_instance.immunities |= set(getattr(existing, "immunities", ()) or ())

        owner_id = f"{id(self)}:{effect_key}"
        effect_instance.owner_id = owner_id
        # Activation this (re)application happened in; see TriggerManager.dispatch (on_ability_post_activate).
        effect_instance.applied_activation = getattr(sim, "current_activation", None) if sim is not None else None
        self.effects[effect_key] = effect_instance
        if _effect_charge_mods(effect_instance):
            reconcile_charge_caps(self)
        self.consider_recalculation(effect_instance)

        if sim is not None:
            self._sim_ref = sim
            if hasattr(sim, "tracker") and sim.tracker is not None and hasattr(sim.tracker, "log_effect_applied"):
                sim.tracker.log_effect_applied(
                    self.name,
                    display_name,
                    current_time,
                    stacks=getattr(effect_instance, "stacks", 1),
                    is_passive=is_passive,
                )
            if getattr(sim, "tracer", None) is not None:
                if existing is not None and not getattr(existing, "is_expired", False):
                    sim.tracer.record_buff_refreshed(
                        current_time,
                        self.name,
                        display_name,
                        stacks=getattr(effect_instance, "stacks", 1),
                        duration=duration,
                    )
                else:
                    sim.tracer.record_buff_applied(
                        current_time,
                        self.name,
                        display_name,
                        stacks=getattr(effect_instance, "stacks", 1),
                        duration=duration,
                        is_passive=is_passive,
                    )
            if hasattr(sim, "triggers") and ability is not None:
                # Only a refresh of this very effect carries its running trigger ICDs over; a new application
                # (nothing active under this key) subscribes with fresh ones.
                is_refresh = existing is not None and not getattr(existing, "is_expired", False)
                icd_saved = sim.triggers.icd_snapshot(owner_id) if is_refresh else None
                sim.triggers.unsubscribe(owner_id)
                effect_tags = (
                    effect.get("tags", ())
                    if isinstance(effect, dict)
                    else getattr(effect, "tags", ())
                )
                for branch in getattr(effect, "branches", ()) or ():
                    sim.triggers.subscribe(
                        owner_id,
                        ability,
                        branch,
                        caster or self,
                        self,
                        effect_key=effect_key,
                        effect_tags=effect_tags,
                    )
                if icd_saved:
                    sim.triggers.icd_restore(owner_id, icd_saved)
                eff_ctx = {
                    "caster": caster or self,
                    "target": self,
                    "tags": frozenset(effect_tags),
                    "effect_tags": frozenset(effect_tags),
                    "ability_spec": getattr(ability, "fqn", None),
                    "include_effect_refreshes": (
                        existing is not None
                        and not getattr(existing, "is_expired", False)
                        and getattr(existing, "fqn", None) == effect_instance.fqn
                        and getattr(existing, "number", None) == effect_instance.number
                    ),
                }
                sim.triggers.dispatch("on_effect_applied", sim, eff_ctx)
                sim.triggers.dispatch("on_effect_received", sim, eff_ctx)

            if (total_ticks > 0 or getattr(effect_instance, "passive_tick_base", None) is not None) and scaled_tick is not None:
                from src.swtorsim.events import DotTick
                sim.schedule_absolute(
                    current_time + scaled_tick,
                    DotTick(caster, self, effect_instance, effect_key=effect_key),
                )
            elif effect_instance.expires_at is not None:
                from src.swtorsim.events import EffectExpire
                sim.schedule_absolute(
                    effect_instance.expires_at,
                    EffectExpire(self, effect_key, effect_instance),
                )

        return effect_key, effect_instance, duration

    @staticmethod
    def _determine_charges(existing_effect, incoming_charges: int) -> int:
        """Caps charges at max_charges if defined, otherwise uses incoming charges."""
        if existing_effect and existing_effect.max_charges is not None:
            return min(existing_effect.max_charges, existing_effect.charges + incoming_charges)
        return incoming_charges

    @staticmethod
    def _determine_duration(existing_effect, extra_duration, current_time):
        """Calculates expiration time for an active effect."""
        new_expires_at = current_time + extra_duration
        if existing_effect and existing_effect.expires_at is not None:
            return max(existing_effect.expires_at, new_expires_at)
        return new_expires_at


    def scale_time_modifier(self, base_time: float) -> float:
        """Scales time durations (override in Player for Alacrity)."""
        return base_time

    def scale_time_total(self, base_time: float) -> float:
        """Scales effect durations and proc cooldowns by total Alacrity (override in Player)."""
        return base_time

    def consider_recalculation(self, effect_instance):
        """Triggers recalculate_stats() only if the applied effect modifies a relevant stat."""
        if getattr(effect_instance, "modifiers", None):
            self.recalculate_stats()

    def recalculate_stats(self):
        """Override in subclasses to perform entity-specific stat math."""
        pass

    def cleanup_expired_effects(self, expired_keys: list):
        """Removes expired effects and triggers stat recalculation if any affected stats."""
        if not expired_keys:
            return
        needs_stat_recalc = False
        removed_charge_mods = []
        sim_ref = getattr(self, "_sim_ref", None)
        for r_id in expired_keys:
            popped_effect = self.effects.pop(r_id, None)
            if popped_effect is None:
                continue
            removed_charge_mods.extend(_effect_charge_mods(popped_effect))
            if hasattr(popped_effect, "is_expired"):
                popped_effect.is_expired = True
            display_name = getattr(popped_effect, "name", None) or getattr(popped_effect, "fqn", None) or r_id
            if sim_ref is not None and hasattr(sim_ref, "tracker") and sim_ref.tracker is not None and hasattr(sim_ref.tracker, "log_effect_removed"):
                sim_ref.tracker.log_effect_removed(self.name, display_name, getattr(sim_ref, "current_time", 0.0))
            if sim_ref is not None and getattr(sim_ref, "tracer", None) is not None:
                sim_ref.tracer.record_buff_expired(getattr(sim_ref, "current_time", 0.0), self.name, display_name)
            owner_id = getattr(popped_effect, "owner_id", None)
            if owner_id and sim_ref is not None and hasattr(sim_ref, "triggers"):
                sim_ref.triggers.unsubscribe(owner_id)
            if getattr(popped_effect, "modifiers", None):
                needs_stat_recalc = True
        if removed_charge_mods:
            reconcile_charge_caps(self, removed_mods=removed_charge_mods)
        if needs_stat_recalc:
            self.recalculate_stats()

    def has_effect(self, effect_name):
        """Returns bool on whether effect is present in entity"""
        direct = self.effects.get(effect_name)
        if direct is not None and not getattr(direct, "is_expired", False):
            return True
        for eff in self.effects.values():
            if getattr(eff, "is_expired", False) or getattr(eff, "is_passive", False):
                continue
            if any("lockout" in t for t in getattr(eff, "tags", ())):
                continue
            if getattr(eff, "name", None) == effect_name or getattr(eff, "fqn", None) == effect_name:
                return True
        return False


class Player(Entity):
    """Represents a player character and all that entails."""
    RECALCULATE_STATS = {"Mastery Stat", "Power Stat", "Bonus Damage", "Critical Stat", "Accuracy", "Armor Penetration", "Alacrity Rating", "Mastery PCT"}

    def __init__(self, name: str, abilities: dict = None, passives: dict = None, resource: str = "Force"):
        super().__init__(name)
        self.next_gcd = 0.0
        self.cooldowns = {}
        self.procs = {}
        self.proc_registry: dict[str, dict[str, Any]] = {}
        self.passive_blueprints = passives or {}
        self.passive_db = {}
        self.tactical_fqn = ""
        self.starting_tactical_fqn = ""
        self.gear_library: dict[str, Any] = {}  # preloaded tactical blueprints for pre-combat swaps
        self.pre_combat = None  # PreCombatRunner while the pre-pull sequence owns decisions
        self.ability_db = self.build_ability_db(abilities or {})
        self.level = 85
        self.rotation = None
        self.toughness = 1
        self.max_hp = 1_000_000
        self.hp = 1_000_000
        self.creature_type = 4
        self.is_droid = False
        self.is_stealthed = False
        self.is_mounted = False
        self.combat_distance = 30.0
        self.is_behind_target = True
        self.is_player = True
        self.in_combat = False
        self.is_in_cover = False
        self.is_in_portable_cover = False
        self.is_stealthed = False
        self.character_class = (name or "assassin").lower()
        self.faction = "empire"
        self.resource = create_resource_pool(
            pool_type=resource
        )
        self.base_stats = {
            "Alacrity": 0.0,
            "Critical Chance": 0.0,
            "Critical Modifier": 0.0,
            "Critical Rating": 0.0,
            "Accuracy Rating": 0.0,
            "Main Accuracy": 0.0,
            "Off Accuracy": 0.0,
            "Melee Accuracy": 0.0,
            "Ranged Accuracy": 0.0,
            "Force Accuracy": 0.0,
            "Tech Accuracy": 0.0,
            "Mastery": 0.0,
            "Power": 0.0,
            "Force Power": 0.0,
            "Tech Power": 0.0,
            "M_Bonus_Damage": 0.0,
            "R_Bonus_Damage": 0.0,
            "F_Bonus_Damage": 0.0,
            "T_Bonus_Damage": 0.0,
            "Alacrity Rating": 0.0,
            "Main_hand_min": 0.0,
            "Main_hand_max": 0.0,
            "Off_hand_min": 0.0,
            "Off_hand_max": 0.0,
            "Standard_health": 0.0,
            "Armor Penetration": 0.0
        }
        # Hidden permanent additive bonuses (Accuracy, Critical Chance, Critical Modifier)
        self.permanent_bonuses: dict[str, float] = {}
        self.stats = self.base_stats.copy()

    @staticmethod
    def build_ability_db(abilities: dict) -> dict:
        """Indexes abilities by both their FQN and their normalized name (e.g. 'thrash')."""
        ability_db = {}
        for key, abl in abilities.items():
            # Store primary key (FQN or original string)
            ability_db[key] = abl
            # Store normalized key
            ability_db[key.lower().replace(" ", "_")] = abl
            # Store normalized human-readable name if available. Some game names carry stray
            # spaces (e.g. "Halted Offensive "): the stripped slug matches the rotation builder,
            # the unstripped one matches name-based lookups (cost/cast/cooldown helpers).
            if hasattr(abl, "name"):
                ability_db[abl.name.strip().lower().replace(" ", "_")] = abl
                ability_db[abl.name.lower().replace(" ", "_")] = abl
        return ability_db

    def break_stealth(self, sim=None) -> None:
        """Breaks active stealth upon performing an aggressive combat action."""
        if not self.is_stealthed and not any(any("stealth" in str(t).lower() for t in getattr(e, "tags", ())) for e in self.effects.values()):
            return
        self.is_stealthed = False
        # Clean up general stealth buffs, preserving combat stealth windows (Force Camouflage / Cloaking Screen)
        stealth_keys = [
            key for key, eff in self.effects.items()
            if not getattr(eff, "is_expired", False)
            and any("stealth" in str(t).lower() for t in getattr(eff, "tags", ()))
            and "combat_stealth" not in getattr(eff, "tags", ())
        ]
        if stealth_keys:
            if sim is None:
                self.cleanup_expired_effects(stealth_keys)
            else:
                # Leaving stealth runs the effect's on_pre_remove branches (the 6 s Stealth cooldown, vanish dispels,
                # talent-conditioned follow-ups) like every other way of removing an effect.
                from src.swtorsim.abilities import remove_effect_firing_pre_remove

                for key in stealth_keys:
                    if key in self.effects:
                        remove_effect_firing_pre_remove(sim, self, key, fallback_caster=self)

    def get_next_action_time(self, current_time: float, sim=None) -> float:
        """Calculates the timestamp for the next rotation evaluation, honoring lead_time on upcoming optional off-GCD steps."""
        base_time = max(current_time, getattr(self, "next_gcd", current_time))
        rotation = getattr(self, "rotation", None)
        if rotation is not None and hasattr(rotation, "get_next_lead_time"):
            lead = rotation.get_next_lead_time(self, current_time, sim)
            if lead > 0.0:
                return max(current_time, round(getattr(self, "next_gcd", current_time) - lead, 4))
        # Round first, then clamp: rounding a time with digits past the 4th decimal can land just below now.
        return max(current_time, round(base_time, 4))

    def calculate_gcd(self, base_gcd: float = 1.5, ability: Any = None) -> float:
        """Calculates GCD duration scaled by Alacrity, rounded up to the nearest tenth of a second as ingame"""
        if base_gcd <= 0.0:
            return 0.0

        flat_mod = 0.0
        pct_mod = 1.0
        alacrity_bonus = 0.0

        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()
            else:
                abl_fqn = getattr(ability, "fqn", None)
                abl_tags = getattr(ability, "tags", frozenset()) or frozenset()
        else:
            abl_fqn = None
            abl_tags = frozenset()

        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            for mod in _effect_modifiers(effect):
                stat = str(mod.stat)
                val = float(mod.value)
                if stat in ("66", "STAT_abl_time_global_cooldown"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        if mod.is_percent:
                            pct_mod += mod.value
                        else:
                            flat_mod += mod.value
                elif stat in ("274", "stat_cbt_instant_reduction_percentage", "STAT_cbt_instant_reduction_percentage"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        alacrity_bonus += val

        adjusted_base = max(0.0, (base_gcd * pct_mod) + flat_mod)
        if adjusted_base <= 0.0:
            return 0.0

        ignore_alacrity = False
        if ability is not None:
            ignore_alacrity = getattr(ability, "abl_ignore_alacrity", False) or getattr(getattr(ability, "blueprint", None), "abl_ignore_alacrity", False)

        total_alacrity = self.stats.get("Alacrity", 0.0) + alacrity_bonus
        gcd = adjusted_base if ignore_alacrity else (adjusted_base / (1.0 + total_alacrity))
        scaled_gcd = math.ceil(round(gcd * 10, 6)) / 10
        return round(scaled_gcd, 2)

    def calculate_cast_time(self, base_cast_time: float, ability: Any = None) -> float:
        """Calculates ability cast time after flat/percentage modifiers (STAT_abl_time_casting, 62) and Alacrity scaling."""
        if base_cast_time <= 0.0:
            return 0.0

        flat_mod = 0.0
        pct_mod = 1.0

        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()
            else:
                abl_fqn = getattr(ability, "fqn", None)
                abl_tags = getattr(ability, "tags", frozenset()) or frozenset()
        else:
            abl_fqn = None
            abl_tags = frozenset()

        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            for mod in _effect_modifiers(effect):
                stat = str(mod.stat)
                val = float(mod.value)
                if stat in ("62", "STAT_abl_time_casting"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        if mod.is_percent:
                            pct_mod += mod.value
                        else:
                            flat_mod += mod.value
                elif stat in ("256", "STAT_cbt_spell_casting_reduction_percentage"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        pct_mod -= val

        adjusted_base = max(0.0, (base_cast_time * pct_mod) + flat_mod)
        if adjusted_base <= 0.0:
            return 0.0

        ignore_alacrity = False
        if ability is not None:
            ignore_alacrity = getattr(ability, "abl_ignore_alacrity", False) or getattr(getattr(ability, "blueprint", None), "abl_ignore_alacrity", False)

        if ignore_alacrity:
            return round(adjusted_base, 4)
        return round(self.scale_time_modifier(adjusted_base), 4)

    def calculate_channel_duration(self, base_duration: float, ability: Any = None) -> float:
        """Calculates channel duration after flat/percentage modifiers (STAT_abl_time_channeling, 63) and Alacrity scaling."""
        if base_duration <= 0.0:
            return 0.0

        flat_mod = 0.0
        pct_mod = 1.0

        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()
            else:
                abl_fqn = getattr(ability, "fqn", None)
                abl_tags = getattr(ability, "tags", frozenset()) or frozenset()
        else:
            abl_fqn = None
            abl_tags = frozenset()

        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            for mod in _effect_modifiers(effect):
                stat = str(mod.stat)
                val = float(mod.value)
                if stat in ("63", "STAT_abl_time_channeling"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        if mod.is_percent:
                            pct_mod += mod.value
                        else:
                            flat_mod += mod.value
                elif stat in ("257", "STAT_cbt_spell_channeling_reduction_percentage"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        pct_mod -= val

        adjusted_base = max(0.0, (base_duration * pct_mod) + flat_mod)
        if adjusted_base <= 0.0:
            return 0.0

        ignore_alacrity = False
        if ability is not None:
            ignore_alacrity = getattr(ability, "abl_ignore_alacrity", False) or getattr(getattr(ability, "blueprint", None), "abl_ignore_alacrity", False)

        if ignore_alacrity:
            return round(adjusted_base, 4)
        return round(self.scale_time_modifier(adjusted_base), 4)

    def calculate_cooldown(self, base_cooldown: float, ability: Any = None) -> float:
        """Calculates ability cooldown after flat/percentage modifiers and scaled by current Alacrity CDR."""
        flat_mod = 0.0
        pct_mod = 1.0
        alacrity_bonus = 0.0
        ignore_alacrity = False

        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()
                ignore_alacrity = getattr(abl_obj, "abl_ignore_alacrity", False) or getattr(getattr(abl_obj, "blueprint", None), "abl_ignore_alacrity", False)
            else:
                abl_fqn = getattr(ability, "fqn", None)
                abl_tags = getattr(ability, "tags", frozenset()) or frozenset()
                ignore_alacrity = getattr(ability, "abl_ignore_alacrity", False) or getattr(getattr(ability, "blueprint", None), "abl_ignore_alacrity", False)

            for effect in self.effects.values():
                if getattr(effect, "is_expired", False):
                    continue
                for mod in _effect_modifiers(effect):
                    stat = str(mod.stat)
                    val = float(mod.value)
                    if stat in ("64", "STAT_abl_time_cooldown"):
                        if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                            if mod.is_percent:
                                pct_mod += mod.value
                            else:
                                flat_mod += mod.value
                    elif stat in ("274", "stat_cbt_instant_reduction_percentage", "STAT_cbt_instant_reduction_percentage"):
                        if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                            alacrity_bonus += val

        adjusted_base = max(0.0, (base_cooldown * pct_mod) + flat_mod)
        if ignore_alacrity:
            return round(adjusted_base, 2)
        cdr = self.stats.get("Alacrity", 0.0) + alacrity_bonus
        cooldown = adjusted_base / (1.0 + cdr)
        scaled_cooldown = math.ceil(cooldown * 10) / 10
        return round(scaled_cooldown, 2)

    def calculate_ability_max_charges(self, base_charges: Optional[int], ability: Any = None) -> Optional[int]:
        """Calculates maximum ability charges after passive/talent modifications."""
        if base_charges is None and ability is None:
            return None

        flat_mod = 0.0
        pct_mod = 1.0
        matched_any = False

        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()
            else:
                abl_fqn = getattr(ability, "fqn", None)
                abl_tags = getattr(ability, "tags", frozenset()) or frozenset()

            for effect in self.effects.values():
                if getattr(effect, "is_expired", False):
                    continue
                if not _effect_has_stat(effect, _MAX_CHARGES_STATS):
                    continue
                for mod in _effect_modifiers(effect):
                    if str(mod.stat) in ("422", "stat_abl_charges_max", "STAT_abl_charges_max"):
                        if mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                            matched_any = True
                            if mod.is_percent:
                                pct_mod += mod.value
                            else:
                                flat_mod += mod.value

        if not matched_any and base_charges is None:
            return None

        current_base = base_charges if base_charges is not None else 1
        return max(1, int(round((current_base * pct_mod) + flat_mod)))

    def calculate_recharge_time(self, base_recharge: float, ability: Any = None) -> float:
        """Calculates charge recharge cooldown after stat_abl_charges_recharge_time (423), cooldown (64) and Alacrity."""
        if base_recharge <= 0.0:
            return 0.0

        flat_mod = 0.0
        pct_mod = 1.0
        ignore_alacrity = False

        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()
                ignore_alacrity = getattr(abl_obj, "abl_ignore_alacrity", False) or getattr(getattr(abl_obj, "blueprint", None), "abl_ignore_alacrity", False)
            else:
                abl_fqn = getattr(ability, "fqn", None)
                abl_tags = getattr(ability, "tags", frozenset()) or frozenset()
                ignore_alacrity = getattr(ability, "abl_ignore_alacrity", False) or getattr(getattr(ability, "blueprint", None), "abl_ignore_alacrity", False)

            _RECHARGE_STATS = ("423", "stat_abl_charges_recharge_time", "STAT_abl_charges_recharge_time")
            _COOLDOWN_STATS = ("64", "STAT_abl_time_cooldown")
            for effect in self.effects.values():
                if getattr(effect, "is_expired", False):
                    continue
                mods = _effect_modifiers(effect)
                has_423 = any(
                    str(m.stat) in _RECHARGE_STATS
                    and m.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags)
                    for m in mods
                )
                target_stats = _RECHARGE_STATS if has_423 else _COOLDOWN_STATS
                for mod in mods:
                    if str(mod.stat) in target_stats and mod.applies_to(ability_fqn=abl_fqn, ability_tags=abl_tags):
                        if mod.is_percent:
                            pct_mod += mod.value
                        else:
                            flat_mod += mod.value

        adjusted_base = max(0.0, (base_recharge * pct_mod) + flat_mod)
        if ignore_alacrity:
            return round(adjusted_base, 2)
        cdr = self.stats.get("Alacrity", 0.0)
        recharge = adjusted_base / (1.0 + cdr)
        scaled_recharge = math.ceil(recharge * 10) / 10
        return round(scaled_recharge, 2)

    def scale_time_modifier(self, base_time: float) -> float:
        """Scales a base time duration using current Alacrity CDR."""
        cdr = self.stats.get("Alacrity",0.0)
        return base_time / (1.0 + cdr)

    def instant_reduction_bonus(self) -> float:
        """Sum of the unconditional instant-reduction bonuses (stat 274) of active effects.

        This is the extra Alacrity-like term the GCD adds to the Alacrity stat (passives such as High Velocity Gas
        Cylinder, stacking buffs such as Supercharged Velocity, Improved Vents).
        """
        total = 0.0
        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            for mod in _effect_modifiers(effect):
                if str(mod.stat) in _INSTANT_REDUCTION_STATS and mod.applies_to():
                    total += float(mod.value)
        return total

    def scale_time_total(self, base_time: float) -> float:
        """Scales effect durations (and so their ticks) and proc cooldowns by total Alacrity.

        Total Alacrity is the Alacrity stat plus the instant-reduction bonuses, the same total the GCD uses.
        Effects applied while the character loads use scale_time_modifier (stat only); see apply_effect.
        """
        return base_time / (1.0 + self.stats.get("Alacrity", 0.0) + self.instant_reduction_bonus())

    def recalculate_stats(self):  # because relics hate me
        """Recalculates a character's stats using its effects."""
        temp_stats = self.base_stats.copy()

        bonuses = defaultdict(float)
        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            for modifier in _effect_modifiers(effect):
                if modifier.targets:
                    continue  # Ability-specific modifiers are evaluated during calculate_hit
                stat = str(modifier.stat)
                val = float(modifier.value)
                if stat in ("STAT_att_mastery", "414", "4140"):
                    if modifier.is_percent:
                        bonuses["Mastery PCT"] += val
                    else:
                        bonuses["Mastery Stat"] += val
                elif stat in ("STAT_rtg_attack_power", "155", "STAT_att_power"):
                    bonuses["Power Stat"] += val
                elif stat in ("STAT_rtg_critical_chance", "STAT_rtg_crit", "156", "Critical Rating"):
                    bonuses["Critical Stat"] += val
                elif stat in ("STAT_rtg_alacrity", "Alacrity Rating", "STAT_rtg_spell_haste", "255"):
                    bonuses["Alacrity Rating"] += val
                elif stat in ("STAT_rtg_accuracy", "154", "Accuracy"):
                    bonuses["Accuracy"] += val
                elif stat in ("STAT_cbtAccuracy", "11"):
                    bonuses["Accuracy"] += val
                elif stat in ("STAT_cbt_melee_accuracy", "114"):
                    bonuses["Melee Accuracy"] += val
                elif stat in ("STAT_cbt_ranged_accuracy", "120"):
                    bonuses["Ranged Accuracy"] += val
                elif stat in ("STAT_cbt_force_accuracy", "232"):
                    bonuses["Force Accuracy"] += val
                elif stat in ("STAT_cbt_tech_accuracy", "233"):
                    bonuses["Tech Accuracy"] += val
                elif stat in ("STAT_cbt_armor_penetration", "166"):
                    bonuses["Armor Penetration"] += val
                elif stat in ("STAT_cbt_melee_damage_bonus", "26"):
                    bonuses["M_Bonus_Damage_PCT"] += val
                elif stat in ("STAT_cbt_ranged_damage_bonus", "25"):
                    bonuses["R_Bonus_Damage_PCT"] += val
                elif stat in ("STAT_cbt_force_damage_bonus", "129"):
                    bonuses["F_Bonus_Damage_PCT"] += val
                elif stat in ("STAT_cbt_tech_damage_bonus", "130"):
                    bonuses["T_Bonus_Damage_PCT"] += val
                elif stat in ("STAT_cbt_damage_bonus",):
                    bonuses["Bonus Damage"] += val
                elif stat in ("STAT_cbt_tech_energy_max", "9"):
                    if modifier.is_percent:
                        bonuses["Tech Energy Max PCT"] += val
                    else:
                        bonuses["Tech Energy Max Stat"] += val
                elif stat in ("STAT_cbt_force_force_max", "10"):
                    if modifier.is_percent:
                        bonuses["Force Max PCT"] += val
                    else:
                        bonuses["Force Max Stat"] += val

        bonuses["Accuracy"] += self.permanent_bonuses.get("Accuracy", 0.0)

        #independent stats
        temp_stats["Mastery"] = (temp_stats["Mastery"] + bonuses["Mastery Stat"]) * (1 + bonuses["Mastery PCT"])
        temp_stats["Power"] += bonuses["Power Stat"]
        temp_stats["Critical Rating"] += bonuses["Critical Stat"]
        temp_stats["Alacrity Rating"] += bonuses["Alacrity Rating"]
        temp_stats["Armor Penetration"] += bonuses["Armor Penetration"]

        #bonus damage
        base_bonus_damage = (temp_stats["Mastery"] * 0.20) + (temp_stats["Power"] * 0.23)
        m_damage_bonus_multiplier = 1 + bonuses["Bonus Damage"] + bonuses["M_Bonus_Damage_PCT"]
        r_damage_bonus_multiplier = 1 + bonuses["Bonus Damage"] + bonuses["R_Bonus_Damage_PCT"]
        f_damage_bonus_multiplier = 1 + bonuses["Bonus Damage"] + bonuses["F_Bonus_Damage_PCT"]
        t_damage_bonus_multiplier = 1 + bonuses["Bonus Damage"] + bonuses["T_Bonus_Damage_PCT"]
        temp_stats["M_Bonus_Damage"] = base_bonus_damage * m_damage_bonus_multiplier
        temp_stats["R_Bonus_Damage"] = base_bonus_damage * r_damage_bonus_multiplier
        force_pwr = temp_stats.get("Force Power", 0.0)
        tech_pwr = temp_stats.get("Tech Power", 0.0)
        temp_stats["F_Bonus_Damage"] = (base_bonus_damage + (force_pwr * 0.23)) * f_damage_bonus_multiplier
        temp_stats["T_Bonus_Damage"] = (base_bonus_damage + (tech_pwr * 0.23)) * t_damage_bonus_multiplier

        #diminishing returns
        alacrity_divisor, alacrity_cap = derived_stat(ALACRITY_RATING, self.level)
        accuracy_divisor, accuracy_cap = derived_stat(ACCURACY_RATING, self.level)
        crit_chance_divisor, crit_chance_cap = derived_stat(
            CRITICAL_RATING, self.level, CRITICAL_CHANCE_TARGET
        )
        crit_damage_divisor, crit_damage_cap = derived_stat(
            CRITICAL_RATING, self.level, CRITICAL_DAMAGE_TARGET
        )
        mastery_divisor, mastery_cap = derived_stat(
            MASTERY, self.level, CRITICAL_CHANCE_TARGET
        )
        temp_stats["Alacrity"] = calc_dr(
            temp_stats["Alacrity Rating"], alacrity_cap, alacrity_divisor, self.level
        )
        acc_base = calc_dr(
            temp_stats["Accuracy Rating"], accuracy_cap, accuracy_divisor, self.level
        )
        critical_chance = calc_dr(
            temp_stats["Critical Rating"], crit_chance_cap, crit_chance_divisor, self.level
        )
        critical_damage = calc_dr(
            temp_stats["Critical Rating"], crit_damage_cap, crit_damage_divisor, self.level
        )
        mastery_cc = calc_dr(
            temp_stats["Mastery"], mastery_cap, mastery_divisor, self.level
        )

        #dependant statts
        temp_stats["Critical Chance"] = (
            0.05 + critical_chance + mastery_cc
            + self.permanent_bonuses.get("Critical Chance", 0.0)
        )
        temp_stats["Critical Modifier"] = (
            0.5 + critical_damage
            + self.permanent_bonuses.get("Critical Modifier", 0.0)
        )
        temp_stats["Main Accuracy"] = 1 + acc_base + bonuses["Accuracy"]
        temp_stats["Off Accuracy"] = 0.70 + acc_base + bonuses["Accuracy"]
        temp_stats["Melee Accuracy"] = temp_stats["Main Accuracy"] + bonuses["Melee Accuracy"]
        temp_stats["Ranged Accuracy"] = temp_stats["Main Accuracy"] + bonuses["Ranged Accuracy"]
        temp_stats["Force Accuracy"] = temp_stats["Main Accuracy"] + bonuses["Force Accuracy"]
        temp_stats["Tech Accuracy"] = temp_stats["Main Accuracy"] + bonuses["Tech Accuracy"]

        self.stats = temp_stats

        # Resource pool max value scaling
        if getattr(self, "resource", None) is not None:
            res = self.resource
            pool_type = getattr(res, "pool_type", "").lower()
            base_max = getattr(res, "base_max_value", res.max_value)

            if pool_type in ("energy", "heat", "ammo"):
                bonus_stat = bonuses.get("Tech Energy Max Stat", 0.0)
                bonus_pct = bonuses.get("Tech Energy Max PCT", 0.0)
            elif pool_type in ("force",):
                bonus_stat = bonuses.get("Force Max Stat", 0.0)
                bonus_pct = bonuses.get("Force Max PCT", 0.0)
            else:
                bonus_stat = 0.0
                bonus_pct = 0.0

            old_max = res.max_value
            new_max = max(1.0, (base_max + bonus_stat) * (1.0 + bonus_pct))
            res.max_value = new_max

            if res.current_value >= old_max and pool_type != "heat":
                res.current_value = new_max
            elif res.current_value > new_max:
                res.current_value = new_max

    def calculate_resource_cost(self, ability_name: str, base_cost: float, apply = False) -> float:
        """Calculates resource cost after percentage/flat adjustments and optionally consumes buff charges."""
        base = max(0.0, float(base_cost or 0.0))
        pct_modifiers = 1.0
        flat_reductions = 0.0
        effects_to_clear = []
        target_ability = ability_name.lower().replace(" ", "_")
        abl_obj = self.ability_db.get(ability_name) or self.ability_db.get(target_ability)
        abl_fqn = getattr(abl_obj, "fqn", None)
        abl_tags = getattr(abl_obj, "tags", frozenset()) or frozenset()

        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            if not _effect_has_stat(effect, _RESOURCE_COST_STATS):
                continue
            for mod in _effect_modifiers(effect):
                if mod.stat in (
                    "68", "69", "70",
                    "STAT_abl_cost_force", "STAT_abl_cost_energy", "STAT_abl_cost_action_points",
                ):
                    matched = mod.applies_to(abl_fqn, abl_tags)
                    if matched:
                        if mod.is_percent:
                            pct_modifiers += mod.value
                        else:
                            flat_reductions += mod.value

        if effects_to_clear:
            self.cleanup_expired_effects(effects_to_clear)

        final_cost = (base * pct_modifiers) + flat_reductions
        return max(0.0, final_cost) #safeguard tbh

    def calculate_resource_regen(self, base_rate: float, pool_type: Optional[str] = None) -> float:
        """Calculates resource regen rate after flat bonuses and percentage modifiers."""
        if pool_type is None:
            pool_type = getattr(getattr(self, "resource", None), "pool_type", "Force")

        is_force = pool_type.lower() in ("force", "focus", "rage")
        is_tech = pool_type.lower() in ("energy", "heat", "ammo")

        flat_bonus = 0.0
        pct_bonus = 0.0

        for effect in self.effects.values():
            if getattr(effect, "is_expired", False):
                continue
            for mod in _effect_modifiers(effect):
                stat = str(mod.stat)
                val = float(mod.value)

                # Force regen
                if is_force:
                    if stat in ("140", "STAT_cbt_force_force_regen_rate"):
                        flat_bonus += val
                    elif stat in ("275", "STAT_cbt_force_force_regen_rate_modifier_percentage"):
                        pct_bonus += val

                # Tech / Energy regen
                if is_tech:
                    if stat in ("142", "STAT_cbt_tech_energy_regen_rate"):
                        flat_bonus += val
                    elif stat in ("276", "STAT_cbt_tech_energy_regen_rate_modifier_percentage"):
                        pct_bonus += val

        final_rate = max(0.0, (base_rate * (1.0 + pct_bonus)) + flat_bonus)
        return final_rate

    def calculate_effect_duration(self, base_duration: float, ability: Any = None, effect: Any = None) -> float:
        """Calculates effect duration after flat and percentage modifiers (STAT_eff_time_duration, 44)."""
        if base_duration <= 0.0:
            return 0.0

        flat_mod = 0.0
        pct_mod = 1.0

        all_tags = set()
        abl_fqn = None
        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                all_tags.update(getattr(abl_obj, "tags", ()) or ())
            else:
                abl_fqn = getattr(ability, "fqn", None)
                all_tags.update(getattr(ability, "tags", ()) or ())

        if effect is not None:
            eff_tags = effect.get("tags", ()) if isinstance(effect, dict) else getattr(effect, "tags", ())
            all_tags.update(eff_tags or ())
            eff_name = effect.get("name") if isinstance(effect, dict) else getattr(effect, "name", None)
            if eff_name:
                all_tags.add(eff_name)

        eff_tags_frozen = frozenset(all_tags)

        for active_eff in self.effects.values():
            if getattr(active_eff, "is_expired", False):
                continue
            for mod in _effect_modifiers(active_eff):
                if str(mod.stat) in ("44", "STAT_eff_time_duration"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=eff_tags_frozen):
                        if mod.is_percent:
                            pct_mod += mod.value
                        else:
                            flat_mod += mod.value

        adjusted = max(0.0, (base_duration * pct_mod) + flat_mod)
        return adjusted

    def calculate_effect_tick(self, base_tick: float, ability: Any = None, effect: Any = None) -> float:
        """Calculates effect tick interval after flat and percentage modifiers (STAT_eff_time_tick, 45)."""
        if base_tick <= 0.0:
            return 0.0

        flat_mod = 0.0
        pct_mod = 1.0

        all_tags = set()
        abl_fqn = None
        if ability is not None:
            if isinstance(ability, str):
                abl_obj = getattr(self, "ability_db", {}).get(ability) or getattr(self, "ability_db", {}).get(ability.lower().replace(" ", "_"))
                abl_fqn = getattr(abl_obj, "fqn", ability)
                all_tags.update(getattr(abl_obj, "tags", ()) or ())
            else:
                abl_fqn = getattr(ability, "fqn", None)
                all_tags.update(getattr(ability, "tags", ()) or ())

        if effect is not None:
            eff_tags = effect.get("tags", ()) if isinstance(effect, dict) else getattr(effect, "tags", ())
            all_tags.update(eff_tags or ())
            eff_name = effect.get("name") if isinstance(effect, dict) else getattr(effect, "name", None)
            if eff_name:
                all_tags.add(eff_name)

        eff_tags_frozen = frozenset(all_tags)

        for active_eff in self.effects.values():
            if getattr(active_eff, "is_expired", False):
                continue
            for mod in _effect_modifiers(active_eff):
                if str(mod.stat) in ("45", "STAT_eff_time_tick"):
                    if mod.applies_to(ability_fqn=abl_fqn, ability_tags=eff_tags_frozen):
                        if mod.is_percent:
                            pct_mod += mod.value
                        else:
                            flat_mod += mod.value

        adjusted = max(0.01, (base_tick * pct_mod) + flat_mod)
        return adjusted


def _effect_modifiers(effect):
    """Returns stack-scaled effective modifiers from an active effect instance."""
    getter = getattr(effect, "get_effective_modifiers", None)
    if getter is None:
        return ()
    return getter()


_INSTANT_REDUCTION_STATS = frozenset({"274", "stat_cbt_instant_reduction_percentage", "STAT_cbt_instant_reduction_percentage"})
_MAX_CHARGES_STATS = frozenset({"422", "stat_abl_charges_max", "STAT_abl_charges_max"})
_RESOURCE_COST_STATS = frozenset({
    "68", "69", "70",
    "STAT_abl_cost_force", "STAT_abl_cost_energy", "STAT_abl_cost_action_points",
})


def _effect_has_stat(effect, stats: frozenset) -> bool:
    """False only when the effect provably carries no modifier for any of ``stats`` (safe to skip)."""
    getter = getattr(effect, "modifier_stats", None)
    if getter is None:
        return True
    return not stats.isdisjoint(getter())


class Dummy(Entity):
    """Represents a dummy and all it entails."""
    RECALCULATE_STATS = {"Armor Rating"}
    def __init__(self, name: str, hp: int):
        super().__init__(name)
        self.max_hp = hp
        self.hp = hp
        self.toughness = 5
        self.creature_type = 1
        self.is_droid = False
        self.is_stealthed = False
        self.is_mounted = False
        self.combat_distance = 30.0
        self.immune_by_resolve = True
        self.in_combat = True
        self.is_in_cover = False
        self.is_in_portable_cover = False
        self.is_stealthed = False
        self.base_stats = {
            "Armor" : 17225
        }
        self.stats = self.base_stats.copy()

    def recalculate_stats(self):
        """Recalculates the dummy's armor."""
        temp_stats = self.base_stats.copy()
        armor_rating_change = 0
        for effect in self.effects.values():
            for modifier in _effect_modifiers(effect):
                if modifier.stat == "STAT_rtg_armor":
                    armor_rating_change += modifier.value
        temp_stats["Armor"] *= (1+armor_rating_change)
        self.stats = temp_stats

    @property
    def hp_ratio(self) -> float:
        """Calculates the meaning of life. Evidently."""
        return self.hp / self.max_hp if self.max_hp > 0 else 1.0
