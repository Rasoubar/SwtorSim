import heapq
from src.swtorsim.metrics import Metrics
from src.swtorsim.triggers import TriggerManager

class Simulation:
    """Manages the event queue and core combat timeline."""
    def __init__(self, in_flashpoint_operation: bool | None = None, verbose: bool = True):
        self.queue = []
        self.current_time = 0.0
        self.event_counter = 0
        self.tracker = Metrics()
        self.triggers = TriggerManager()
        self.verbose = verbose
        from src.swtorsim.settings import is_in_flashpoint_operation
        self.in_flashpoint_operation = (
            bool(in_flashpoint_operation)
            if in_flashpoint_operation is not None
            else is_in_flashpoint_operation()
        )

    def schedule_relative(self, delay, event):
        self.event_counter += 1
        heapq.heappush(self.queue, (self.current_time + delay, self.event_counter, event))

    def schedule_absolute(self, absolute_time, event):
        self.event_counter += 1
        heapq.heappush(self.queue, (absolute_time,self.event_counter, event))

    def run_timed(self, duration=300.0, target=None):
        while self.queue:
            if self.queue[0][0] > duration:
                break
            timestamp, seq, event = heapq.heappop(self.queue)
            self.current_time = timestamp
            event.resolve(self)
            if target is not None and getattr(target, "hp", 1) <= 0:
                if self.verbose:
                    print(f"\n[{timestamp:.2f}s] Rip dummy.")
                break
